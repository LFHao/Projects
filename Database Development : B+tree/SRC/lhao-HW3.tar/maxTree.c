/*
     Find the maximum of all the keys.
 */

#include "def.h"

extern FILE *fpbtree;

maxTree( )
{
	printf("!!!! Please Implement maxTree !!!!\n");
}

