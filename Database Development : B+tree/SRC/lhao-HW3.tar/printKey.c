#include "def.h"

printKey(p)
struct KeyRecord *p;
{
    printf("%s\n", p->StoredKey);
}
