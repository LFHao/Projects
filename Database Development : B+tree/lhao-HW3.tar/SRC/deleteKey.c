#include "def.h"

/************************
 You need to complete the function deleteKey().
 
 What you want to do is prompt the user for a key to delete, get that key,
 find the node it belongs to and delete it. Inform the user of the outcome (e.g. success/failure/...)
 
 This is a generic declaration that you can modify in any way you see fit.
 
 FYI, the within the tree structure, the root has "level" 0, and leaves have the highest level
***************************/

deleteKey(key)
char *key;
{
    printf("**** Ignore me, please!!!! \n");
}




