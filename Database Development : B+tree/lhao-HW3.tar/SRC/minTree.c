/*
     Find the minimum of all the keys.
 */

#include "def.h"

extern FILE *fpbtree;

minTree( )
{
	printf("!!!! Please Implement minTree !!!!\n");
}

